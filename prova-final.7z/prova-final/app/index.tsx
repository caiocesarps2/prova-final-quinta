import TelaPiada from "../src/screens/TelaPiada"


export default function TelaPiadas (){
    return (
        <TelaPiada/>
    )
}