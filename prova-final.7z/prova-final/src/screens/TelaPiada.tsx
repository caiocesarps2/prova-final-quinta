import React, { useState } from "react";
import { Button } from "react-native";
import styled from 'styled-components/native';

export default function TelaPiada () {
    const [piada, setPiada] = useState("");

    const dadosApi = async () => {
        try {
            const response = await fetch('https://v2.jokeapi.dev/joke/Any?lang=pt&type=twopart');
            const json = await response.json();
            setPiada(`Piada: ${json.setup} \n\nResposta: ${json.delivery}`);
        } catch (error) {
            console.error('Erro ao buscar dados da API:', error);
            setPiada("Erro ao carregar piada.");
        }
    };

    return(
        <Container>
            <TextoPrincipal>
                Gerador de Piadas
            </TextoPrincipal>
            <TextArea>{piada}</TextArea>
            <Button
                title="Gerar Piada"
                color="#000"
                accessibilityLabel="Gerar uma piada aleatória"
                onPress={dadosApi}
            />
        </Container>
    )
}

const Container = styled.View`
    flex: 1;
    background-color: #fdfdfd;
    align-items: center;
    justify-content: center;
    padding: 20px;
`;

const TextoPrincipal = styled.Text`
    font-size: 20px;
    font-weight: bold;
`;

const TextArea = styled.Text`
    border: 1px solid black;
    border-radius: 5px;
    padding: 10px;
    margin-bottom: 20px;
    margin-top: 20px;
    width: 300px;
    min-height: 100px;
    text-align: center;
`;
